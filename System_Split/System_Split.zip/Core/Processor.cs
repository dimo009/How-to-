﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Processor
{
    public void Run()
    {
        ComponentsManager cm = new ComponentsManager();

        string input = Console.ReadLine();

        while (!input.Equals("System Split"))
        {
            var data = input.Split(new char[] { '(', ')', ',', ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();

            var command = data[0].Trim();

            switch (command)
            {
                case "RegisterPowerHardware":
                    cm.RegisterPowerHardware(data);
                break;

                case "RegisterHeavyHardware":
                    cm.RegisterHeavyHardware(data);
                    break;

                case "RegisterLightSoftware":
                    cm.RegisterLightSoftware(data);
                    break;

                case "RegisterExpressSoftware":
                    cm.RegisterExpressSoftware(data);
                    break;

                case "Analyze":
                    cm.Analyze();
                    break;

                case "ReleaseSoftwareComponent":
                    cm.ReleaseSoftwareComponent(data);
                    break;

               
                default:
                    break;
            }
            input = Console.ReadLine();
        }

        cm.SystemSplit();


    }

}
